---
layout: text
permalink: "/OPS/xhtml/caution.xhtml"
---
{: .caution}
　本作品は、再ダウンロード時に予告なく改訂されている可能性があります。

{: .caution}
　本作品は、縦書きでレイアウトされています。
　ご覧になるリーディングシステムにより、表示に差異が認められることがあります。